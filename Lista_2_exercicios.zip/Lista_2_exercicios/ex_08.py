print("=====ALUNOS=====")
print(" ")

# Array das lojas
alunos = ["matheus", "vitor", "Fernando", "Leonardo"]

# Exibindo lojas
for i, loja in enumerate(alunos, 1):
    print(f"{i} - {loja}")
    print(" ")

